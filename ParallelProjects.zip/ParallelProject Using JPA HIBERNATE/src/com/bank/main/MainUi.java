package com.bank.main;
import java.util.Scanner;

import com.bank.entity.BankDetails;
import com.bank.entity.TransactionDetails;
import com.bank.service.BankService;
public class MainUi {
	public static void Menu()
	{
		System.out.println("\n\n\n*************BANK APPLICATION***************");
		System.out.println("*********************************************************");
		System.out.println("1. CreateAccount\n2. Show Balance\n3. Deposit\n4. WithDraw\n5. Fund Transfer\n6. Print Transaction\n7. Exit");
		System.out.println("*-**-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*--*--*-*-*-*-*-*-*-*-*-*-\n");
	}
	public static void main(String[] args) throws InvalidException {
		do{
			Menu();
		
		 Scanner sc=new Scanner(System.in);
		 BankService service=new BankService();
		 BankDetails bank=new BankDetails();
		 TransactionDetails trans=new TransactionDetails();
		 TransactionDetails trans1=new TransactionDetails();
	 int opt=sc.nextInt();
		 
	 switch(opt)
	 {
	 case 1:
		 System.out.println("Fill the reqiured details to create Account\n");
		 System.out.println("Enter Account Name");
		 String name=sc.next();
		 if(name==null||name.length()>12)
		 {
			 throw new InvalidException("Enter valid Name ");
		 }
		 System.out.println("Enter Mobile Number");
		 String mobileno=sc.next();
		 if(mobileno.length()!=10)
		 {
			 throw new InvalidException("Enter valid Mobile Number");
		 }
		 
		 bank.setAccId();
		 bank.setAccountantName(name);
		 bank.setMobileno(mobileno);
		 bank.setAccBalance(1000);
		 
		 
		 service.CreateAccount(bank);		//Service class calling
		 
		 System.out.println("Inserted Successfully ......");
		 int id=bank.getAccId();
		 service.getAccountById(id);
		 System.out.println("Your ACCOUNT ID is :"+bank.getAccId());
		 
		 System.out.println("-------------------------------------------------------------");
	  break;
	 case 2:
		 System.out.println("Enter your account id for Balance enquiry");
		 int accid=sc.nextInt();
		 if(accid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=service.getAccountById(accid);
		 System.out.println("Accountant Name: "+bank.getAccountantName());
		 System.out.println(" YOur Account Balance is: "+bank.getAccBalance());
		 System.out.println("\n-------------------------------------------------------------");
		 break;
		 
	 case 3:
		 System.out.println("Deposit Module...!!");
		 System.out.println("Enter your Account ID");
		 int depId=sc.nextInt();
		 if(depId==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=service.getAccountById(depId);	
		 System.out.println("Accountant Name: "+bank.getAccountantName());
		 System.out.println(" Your Account Balance is: "+bank.getAccBalance());
		 int initbal=bank.getAccBalance();
		 System.out.println("Enter the Amount you want to Deposit");
		 int depAmt=sc.nextInt();
		 int finalbal=initbal+depAmt;
		 bank.setAccBalance(finalbal);
		 service.Deposit(bank);

		 //Updating In Transaction Table
		 
		 trans.setTransactionType("Deposit");
		 trans.setAccId(depId);
		 trans.setAmount(depAmt);
		 service.addTransaction(trans);
		 bank.setT(trans);
		 
		 
		 bank=service.getAccountById(depId);
		 System.out.println("Hello  "+bank.getAccountantName());
		 System.out.println("Your Account Balance after Depositing "+depAmt+" Rs is "+bank.getAccBalance());
		 System.out.println("\n-------------------------------------------------------------\n");
		 break;
	 case 4:
		 System.out.println("Withdraw Module");
		 System.out.println("Enter your account Id");
		 int wid=sc.nextInt();
		 if(wid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=service.getAccountById(wid);						
		 System.out.println("Hello... "+bank.getAccountantName());
		 System.out.println(" Your Account Balance is: "+bank.getAccBalance());
		 int intbal=bank.getAccBalance();							//initial balance
		 System.out.println("-------------------------------------------");
		 System.out.println("Enter the Amount you want to Withdraw");
		 int wamt=sc.nextInt();
		 int finalBal=intbal-wamt;
		 bank.setAccBalance(finalBal);
 		 service.Withdraw(bank);
 		 
 		 
		 //Updating In Transaction Table
		 trans.setTransactionType("Withdraw");
		 trans.setAccId(wid);
		 trans.setAmount(wamt);
		 service.addTransaction(trans);
		 bank.setT(trans);
		 
		 bank=service.getAccountById(wid);
		 System.out.println("Hello ................ "+bank.getAccountantName());
		 System.out.println("Your Remaining Account Balance after Withdraw "+wamt+" Rs is"+bank.getAccBalance());
		 System.out.println("\n-------------------------------------------------------------\n");
		 break;
	 case 5:
		 System.out.println("Fund Transfer....!!");
		 System.out.println("Enter the From Account ID");
		 int fid=sc.nextInt();	//From Account Id (Sender)
		 if(fid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=service.getAccountById(fid);
		 int bal=bank.getAccBalance();						//Initial Balance
		 System.out.println("Enter the amount you want to transfer");
		 int fund=sc.nextInt();	//Amount to be transfered
		 System.out.println("Enter Reciever Account Id");
		 
		 int tid=sc.nextInt();
		 if(tid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 
		//Removing the Balance transfered from sender Account 
		 bank=service.getAccountById(fid);
		 int bal1=bal-fund;
		 bank.setAccBalance(bal1);
		 service.Deposit(bank);
		 
		 //updating the Balance recieved from Sender
		 bank=service.getAccountById(tid);
		 int tbal=bank.getAccBalance();
		 int tbalance=tbal+fund;
		 bank.setAccBalance(tbalance);
		 service.Deposit(bank);
		
		 
		 //updating In transaction Table
		 trans.setTransactionType("Transfered to "+tid);
		 trans.setAccId(fid);
		 trans.setAmount(fund);
		 service.addTransaction(trans);
		 bank.setT(trans);
		 int a= trans.getTransactionId();
		 
		/*//Updating In transaction Table
		 trans1.setTransactionId(a);
		 trans1.setTransactionType("Recieved From"+fid);
		 trans1.setAccId(tid);
		 trans1.setAmount(fund);
		 service.addTransaction(trans1);
		 bank.setT(trans1);
		 
		 */
		
		 bank=service.getAccountById(fid);
		 System.out.println("helooo...."+bank.getAccountantName());
		 System.out.println("Remaining balance in account "+bank.getAccBalance());
		 System.out.println("\n-------------------------------------------------------------\n");
		 break;
		 
	 case 6:
		System.out.println("Print Transaction");
		System.out.println("Enter the account id");
		int trid=sc.nextInt();
		//trans.setAccId(trid);
		service.PrintTransactions(trid);
		 System.out.println("\n\n-------------------------------------------------------------");
		 break;
	 case 7:
		 System.out.println("Thankyou For using our Bank Services...................!!!");
		 System.exit(0);
	 }
	}while(true);
}
}